## Firefox Shortcuts for Google Translate

### Overview
Adds missing keybindings support for https://translate.google.com

Defaults are:

[Alt]+[D] - Swap languages

[Alt]+[J] - Output panel audio

[Alt]+[K] - Clear text

[Alt]+[L] - Input panel audio

[Alt]+[N] - Microphone
