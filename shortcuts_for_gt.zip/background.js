// console.log('background.js started');

// var opening = browser.runtime.openOptionsPage();
// opening.then(onOpened, onError);


// browser.runtime.onMessage.addListener((message, sender, sendResponse) => {
//   console.log(message);
// });


// browser.commands.onCommand.addListener((name) => {
//   console.log(name);
// });
